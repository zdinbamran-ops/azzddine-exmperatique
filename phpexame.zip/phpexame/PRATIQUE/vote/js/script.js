/**
 * script.js
 * Gestion du modal de vote et interactions JavaScript
 */

document.addEventListener('DOMContentLoaded', function () {

    // Éléments du DOM
    const modal = document.getElementById('modal-vote');
    const formVote = document.getElementById('form-vote');
    const inputIdCandidat = document.getElementById('id_candidat');
    const inputIdEtudiant = document.getElementById('id_etudiant');
    const nomCandidatSelectionne = document.getElementById('nom-candidat-selectionne');
    const btnFermerModal = document.getElementById('btn-fermer-modal');
    const btnAnnuler = document.getElementById('btn-annuler');
    const boutonsVoter = document.querySelectorAll('.btn-voter[data-id]');

    /**
     * Ouvre le modal avec le candidat sélectionné
     * @param {string} idCandidat - ID du candidat
     * @param {string} nomCandidat - Nom du candidat
     */
    function ouvrirModal(idCandidat, nomCandidat) {
        inputIdCandidat.value = idCandidat;
        nomCandidatSelectionne.textContent = nomCandidat;
        inputIdEtudiant.value = '';
        modal.classList.add('active');
        modal.setAttribute('aria-hidden', 'false');
        inputIdEtudiant.focus();
    }

    /**
     * Ferme le modal
     */
    function fermerModal() {
        modal.classList.remove('active');
        modal.setAttribute('aria-hidden', 'true');
    }

    // Clic sur un bouton "Voter" d'une carte candidat
    boutonsVoter.forEach(function (bouton) {
        bouton.addEventListener('click', function () {
            const idCandidat = this.getAttribute('data-id');
            const nomCandidat = this.getAttribute('data-nom');
            ouvrirModal(idCandidat, nomCandidat);
        });
    });

    // Fermer le modal avec le bouton X
    btnFermerModal.addEventListener('click', fermerModal);

    // Fermer le modal avec le bouton Annuler
    btnAnnuler.addEventListener('click', fermerModal);

    // Fermer le modal en cliquant en dehors du contenu
    modal.addEventListener('click', function (event) {
        if (event.target === modal) {
            fermerModal();
        }
    });

    // Fermer le modal avec la touche Échap
    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && modal.classList.contains('active')) {
            fermerModal();
        }
    });

    // Validation côté client avant envoi du formulaire
    formVote.addEventListener('submit', function (event) {
        const idEtudiant = inputIdEtudiant.value.trim();

        if (idEtudiant === '') {
            event.preventDefault();
            alert('Veuillez saisir votre identifiant étudiant.');
            inputIdEtudiant.focus();
            return;
        }

        // Confirmation avant validation définitive du vote
        const nom = nomCandidatSelectionne.textContent;
        const confirmer = confirm(
            'Confirmez-vous votre vote pour ' + nom + ' ?\n\nCe choix est définitif.'
        );

        if (!confirmer) {
            event.preventDefault();
        }
    });
});
